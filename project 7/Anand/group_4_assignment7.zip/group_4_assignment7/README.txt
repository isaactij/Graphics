Open the group_4_assignment7 file and press run. Follow the instructions on the
screen and press w to go up, s to go down, a to go left, and d to go right. Make
sure that the sound library is downloaded.
