To run this application open the file group_4_assignment5.pde and press run.
